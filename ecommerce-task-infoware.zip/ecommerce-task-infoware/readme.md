This Website is Deployed on Heroku
Visit the App:
https://ecommerce-app-hamza-khan.herokuapp.com/

### Website Pages

###### Home

###### Products

###### Product Item

###### Register

###### Login

To start the app

Run

#### npm run dev

in the root terminal

### Login and Register Auth

User database is maintained in MongoDB for Registered Users and data is used for Login in users

## For Updating Products in Mongo Db

Add data in products.json

save the data

and run

## npm run seed

to update data for products
